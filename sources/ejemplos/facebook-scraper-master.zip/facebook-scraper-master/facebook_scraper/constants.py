FB_BASE_URL = 'https://facebook.com/'
FB_MOBILE_BASE_URL = 'https://m.facebook.com/'

DEFAULT_REQUESTS_TIMEOUT = 5
DEFAULT_PAGE_LIMIT = 10
